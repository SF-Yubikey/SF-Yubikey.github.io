#!/bin/bash
COOKIE="flt=0; BOX.SessionCacheKey.SessID=81e198c1-d5dd-4e2d-b9bd-5858e6caff98; x-server=WCU; gatewaydc=san; BOX.SessionCacheKey.CurrentTenantIdKey=8f0b63e1-f094-4d6b-bae2-b495966c70fc; BOX.SessionCacheKey.UpnFromCurrentTenant=cjiang@sfinsider.onmicrosoft.com"
SESSIONCTX="775mOnJg2l8R3vht6r3/VEN8Q1oHKp7KKeD+tQ7YE92zSfRS6Iag2Q4FlEHbrGIgXZq3/69v/UwUpaeZ57a1IknvnF4SLPotEXL/o6rENdKtq81IsYwgfJgm6CYjuKSq4vSBTnvFq/kSxTBgreJ2ZsaAa2IeDDWRi0FVxuxHvT7neeceRPBPbSUX5NmVbtiwa9JezVVTv1HAIcs5wNjw/HI4Lg53n9Eq1b0S5ylL3MRvRzWrav+BBBNu6JlgSS3f2Ww284MIkkJwDSqeDgZObbqbBso+Sn4oIPvjZVBdDA9kJcl5ok3KZREXmKEsd2IyMykEtXOwIjvFtIF6IVeVeW/hXc+TJCpq9RRONhVMhudrFoJe8aZIRW7gLxoizu0lXeoklj2sVcnB8IRmwRRn1A=="
BEARER="eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6ImtnMkxZczJUMENUaklmajRydDZKSXluZW4zOCIsImtpZCI6ImtnMkxZczJUMENUaklmajRydDZKSXluZW4zOCJ9.eyJhdWQiOiIwMDAwMDAwYy0wMDAwLTAwMDAtYzAwMC0wMDAwMDAwMDAwMDAiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC84ZjBiNjNlMS1mMDk0LTRkNmItYmFlMi1iNDk1OTY2YzcwZmMvIiwiaWF0IjoxNjA3MTI0MDAwLCJuYmYiOjE2MDcxMjQwMDAsImV4cCI6MTYwNzEyNzkwMCwiYWNyIjoiMSIsImFjcnMiOlsidXJuOnVzZXI6cmVnaXN0ZXJzZWN1cml0eWluZm8iLCJ1cm46bWljcm9zb2Z0OnJlcTEiLCJ1cm46bWljcm9zb2Z0OnJlcTIiLCJ1cm46bWljcm9zb2Z0OnJlcTMiLCJjMSIsImMyIiwiYzMiLCJjNCIsImM1IiwiYzYiLCJjNyIsImM4IiwiYzkiLCJjMTAiLCJjMTEiLCJjMTIiLCJjMTMiLCJjMTQiLCJjMTUiLCJjMTYiLCJjMTciLCJjMTgiLCJjMTkiLCJjMjAiLCJjMjEiLCJjMjIiLCJjMjMiLCJjMjQiLCJjMjUiXSwiYWlvIjoiQWFRQVcvOFJBQUFBSjRURjJYaTVyc0ROREUzc0Z1SHRZa2NoVUZCdDFYR2R2UmNJeHN5MXlRUFZSc2NDSGhrcFJMc3dCSThDK1hyVVcvbWJNUkhmbit3aXo3WlowTjFxeTBiL1NSYW0wdk1JNVl1NVk4VERKN1pQTTBwNkJGVjFsQmJjOVFJdXowZ1orQnpMQW51MjZDVHg1K1NyYmdwSGdMUEEwS3B0ekZXMk50amJDd1E0YXVLYjB3THBIbC9rd2hWeVF6RVFUdGVZWEJOQnB0eHF2cDR3aVBYNmc4RnEvZz09IiwiYW1yIjpbInJzYSIsIm1mYSJdLCJhcHBpZCI6IjE5ZGI4NmMzLWIyYjktNDRjYy1iMzM5LTM2ZGEyMzNhM2JlMiIsImFwcGlkYWNyIjoiMCIsImZhbWlseV9uYW1lIjoiSmlhbmciLCJnaXZlbl9uYW1lIjoiQ2FsZWIiLCJpcGFkZHIiOiI0Ny4xODcuNS4xOTYiLCJuYW1lIjoiQ2FsZWIgSmlhbmciLCJvaWQiOiJhMWVkYjcwZi0zZGRlLTQ2ODgtYjBmYy0zYTkwYjYzYzIzZTIiLCJwdWlkIjoiMTAwMzIwMDBFNEQ5QjQwOCIsInJoIjoiMC5BUzBBNFdNTGo1VHdhMDI2NHJTVmxteHdfTU9HMnhtNXNzeEVzemsyMmlNNk8tSXRBSFUuIiwic2NwIjoidGVuYW50cy5yZWFkIiwic3ViIjoiMHdIbWxLQTJVd0VjTmVKbm5UN3pQM1pxaGI5ZXBwUnlSWGYzdUxVcTFldyIsInRlbmFudF9yZWdpb25fc2NvcGUiOiJOQSIsInRpZCI6IjhmMGI2M2UxLWYwOTQtNGQ2Yi1iYWUyLWI0OTU5NjZjNzBmYyIsInVuaXF1ZV9uYW1lIjoiY2ppYW5nQHNmaW5zaWRlci5vbm1pY3Jvc29mdC5jb20iLCJ1cG4iOiJjamlhbmdAc2ZpbnNpZGVyLm9ubWljcm9zb2Z0LmNvbSIsInV0aSI6IkhSNm5FUTBRNzBTMlFoM3dMd3F1QUEiLCJ2ZXIiOiIxLjAiLCJ3aWRzIjpbImI3OWZiZjRkLTNlZjktNDY4OS04MTQzLTc2YjE5NGU4NTUwOSJdLCJ4bXNfdGNkdCI6MTU0MzU5ODkxOX0.kgnQJUnVW5IS5foKBnmMi4rT86MFg7pbQtQH4stI7i6JdNpZ_ke6G4gzV8GCzaHs5KRJR2OS-xni_VgwOeSSV70hrtcxD5Xk_aYO3BL6PE31NXhd2MWPmzXWxdgd1VJXmt1xQvTeZUGttcgr4uJ1v_yeCzFektyBVJMmzHr6cKCF75K1lbkFx7Oirsv_WBXDlMIL9YvUuSromgRotkmyAgq4dzMC2D2rHBdW1U3xUigOHnAd06udhGycl0_92oJSPtcWBcs5SYp6y2TefSOX62JPbS0dIj2Iyo1RMQNT79rbINaAGYj6Zv1KKIG45-VZDHfJzTB8SbfhpKQ5mDdIZQ"

curl 'https://account.activedirectory.windowsazure.com/securityinfo/InitializeMobileAppRegistration' \
  -H 'Connection: keep-alive' \
  -H 'Authorization: Bearer '"$BEARER" \
  -H 'DNT: 1' \
  -H 'AjaxRequest: true' \
  -H 'Content-Type: application/json' \
  -H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36' \
  -H 'SessionCtx: '"$SESSIONCTX" \
  -H 'Accept: */*' \
  -H 'Origin: https://mysignins.microsoft.com' \
  -H 'Sec-Fetch-Site: cross-site' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: https://mysignins.microsoft.com/' \
  -H 'Accept-Language: en-US,en;q=0.9,la;q=0.8' \
  -H 'Cookie: '"$COOKIE" \
  --data-binary '{"securityInfoType":3}' \
  --compressed > out.txt

grep -Po '"SecretKey":.*?[^\\]"' out.txt > key.txt
KEYTXT=`cat key.txt`
KEY=${KEYTXT:13:16}

curl 'https://account.activedirectory.windowsazure.com/securityinfo/AddSecurityInfo' \
  -H 'Connection: keep-alive' \
  -H 'Authorization: Bearer '"$BEARER" \
  -H 'DNT: 1' \
  -H 'AjaxRequest: true' \
  -H 'Content-Type: application/json' \
  -H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36' \
  -H 'SessionCtx: '"$SESSIONCTX" \
  -H 'Accept: */*' \
  -H 'Origin: https://mysignins.microsoft.com' \
  -H 'Sec-Fetch-Site: cross-site' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: https://mysignins.microsoft.com/' \
  -H 'Accept-Language: en-US,en;q=0.9,la;q=0.8' \
  -H 'Cookie: '"$COOKIE" \
  --data-binary '{"Type":3,"Data":"{\"secretKey\":\"'"$KEY"'\",\"affinityRegion\":null}"}' \
  --compressed > out2.txt

grep -Po '"VerificationContext":.*?[^\\]"' out2.txt > context.txt
CONTEXTTXT=`cat context.txt`
CONTEXT=${CONTEXTTXT:23:300}

echo "Please add $KEY to your authenticator and enter the current code: "

read CURRENTCODE

curl 'https://account.activedirectory.windowsazure.com/securityinfo/VerifySecurityInfo' \
  -H 'Connection: keep-alive' \
  -H 'Authorization: Bearer '"$BEARER" \
  -H 'DNT: 1' \
  -H 'AjaxRequest: true' \
  -H 'Content-Type: application/json' \
  -H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36' \
  -H 'SessionCtx: '"$SESSIONCTX" \
  -H 'Accept: */*' \
  -H 'Origin: https://mysignins.microsoft.com' \
  -H 'Sec-Fetch-Site: cross-site' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Referer: https://mysignins.microsoft.com/' \
  -H 'Accept-Language: en-US,en;q=0.9,la;q=0.8' \
  -H 'Cookie: '"$COOKIE" \
  --data-binary '{"Type":3,"VerificationContext":"'"$CONTEXT"'","VerificationData":"'"$CURRENTCODE"'"}' \
  --compressed > out3.txt

rm out3.txt
rm out2.txt
rm out.txt
rm context.txt